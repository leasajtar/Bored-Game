package com.boredgame.controller;

import com.boredgame.service.EventService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class FindController {

    private final EventService eventService;

    public FindController(EventService eventService) {
        this.eventService = eventService;
    }

    @GetMapping("/find")
    public String findPage() {
        return "find";
    }
    @GetMapping("/")
    public String home() {
        return "redirect:/find";
    }
}